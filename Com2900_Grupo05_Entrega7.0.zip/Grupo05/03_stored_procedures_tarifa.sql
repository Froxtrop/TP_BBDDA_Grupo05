/***********************************************************************
 * Enunciado: Cree la base de datos, entidades y relaciones. Incluya
 *		restricciones y claves. Deber� entregar un archivo .sql con 
 *		el script completo de creaci�n (debe funcionar si se lo ejecuta
 *		�tal cual� es entregado en una sola ejecuci�n).
 *
 * Fecha de entrega: 01/07/2025
 *
 * N�mero de comisi�n: 2900
 * N�mero de grupo: 05
 * Materia: Bases de datos aplicada
 *
 * Integrantes:
 *		- 44689109 | Crego, Agustina
 *		- 44510837 | Crotti, Tom�s
 *		- 44792728 | Hoffmann, Francisco Gabriel
 *
 ***********************************************************************/
USE Com2900G05;
GO

/*
  _____          _  __       
 |_   _|_ _ _ __(_)/ _| __ _ 
   | |/ _` | '__| | |_ / _` |
   | | (_| | |  | |  _| (_| |
   |_|\__,_|_|  |_|_|  \__,_|
                             
*/

/***********************************************************************
Nombre del procedimiento: socios.cargar_tarifa_cat_sp
Descripci�n: Cargar tarifa categoria
Autor: Grupo 05 - Com2900
***********************************************************************/
CREATE OR ALTER PROCEDURE socios.cargar_tarifa_cat_sp
	@id_categoria INT,
	@vigente_desde DATE = NULL,
	@vigente_hasta DATE = NULL,
	@valor DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;

	-- Validamos el valor
	IF @valor IS NULL OR @valor < 0
	BEGIN
		RAISERROR('El valor de la tarifa debe ser positivo.', 16, 1);
		RETURN;
	END

	-- Validamos la categor�a
	IF NOT EXISTS(SELECT 1 FROM socios.Categoria WHERE id_categoria = @id_categoria)
	BEGIN
		RAISERROR('La Categoria no existe.', 16, 1);
		RETURN;
	END

	IF @vigente_desde IS NULL
        SET @vigente_desde = GETDATE();

	-- Validaci�n de fechas
	IF @vigente_desde IS NOT NULL AND @vigente_hasta IS NOT NULL
	BEGIN
		IF @vigente_desde > @vigente_hasta
		BEGIN
		    RAISERROR('La fecha de inicio no puede ser mayor que la fecha de fin.', 16, 1);
			RETURN;
		END
	END

	DECLARE @fecha_null DATE = '9999-12-31';
	-- Validar que no exista una tarifa para esas fechas
    IF EXISTS (
        SELECT 1 
        FROM socios.TarifaCategoria
        WHERE id_categoria = @id_categoria
			AND (
				-- Condici�n de solapamiento:
				-- El inicio del nuevo rango (@vigente_desde) es menor o igual al fin del rango existente (o "sin limite").
				@vigente_desde <= ISNULL(vigencia_desde, @fecha_null)
				AND
				-- El inicio del rango existente (vigente_desde) es menor o igual al fin del nuevo rango (o "sin limite").
				vigencia_hasta <= ISNULL(@vigente_hasta, @fecha_null)
			)
    )
    BEGIN
        RAISERROR('Ya existe una tarifa vigente para las fechas dadas.', 16, 1);
		RETURN;
	END

	INSERT INTO socios.TarifaCategoria(
        id_categoria,
        vigencia_desde,
        vigencia_hasta,
        valor
    )
    VALUES (
        @id_categoria,
        @vigente_desde,
        @vigente_hasta,
        @valor
    );
END
GO

/***********************************************************************
Nombre del procedimiento: socios.cargar_tarifa_dep_sp
Descripci�n: Cargar tarifa deportiva
Autor: Grupo 05 - Com2900
***********************************************************************/
CREATE OR ALTER PROCEDURE socios.cargar_tarifa_dep_sp
	@id_actividad_dep INT,
	@vigente_desde DATE = NULL,
	@vigente_hasta DATE = NULL,
	@valor DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;

	-- Validamos el valor
	IF @valor IS NULL OR @valor < 0
	BEGIN
		RAISERROR('El valor de la tarifa debe ser positivo.', 16, 1);
		RETURN;
	END

	-- Validamos el valor
	IF NOT EXISTS(SELECT 1 FROM socios.ActividadDeportiva WHERE id_actividad_dep = @id_actividad_dep)
	BEGIN
		RAISERROR('La actividad deportiva no existe.', 16, 1);
		RETURN;
	END

	IF @vigente_desde IS NULL
        SET @vigente_desde = GETDATE();

	-- Validaci�n de fechas
	IF @vigente_desde IS NOT NULL AND @vigente_hasta IS NOT NULL
	BEGIN
		IF @vigente_desde > @vigente_hasta
		BEGIN
		    RAISERROR('La fecha de inicio no puede ser mayor que la fecha de fin.', 16, 1);
			RETURN;
		END
	END

	DECLARE @fecha_null DATE = '9999-12-31';
	-- Validar que no exista una tarifa para esas fechas
    IF EXISTS (
        SELECT 1 
        FROM socios.TarifaActividadDeportiva
        WHERE id_actividad_dep = @id_actividad_dep
			AND (
				-- Condici�n de solapamiento:
				-- El inicio del nuevo rango (@vigente_desde) es menor o igual al fin del rango existente (o "sin limite").
				@vigente_desde <= ISNULL(vigente_hasta, @fecha_null)
				AND
				-- El inicio del rango existente (vigente_desde) es menor o igual al fin del nuevo rango (o "sin limite").
				vigente_desde <= ISNULL(@vigente_hasta, @fecha_null)
			)
    )
    BEGIN
        RAISERROR('Ya existe una tarifa vigente para las fechas dadas.', 16, 1);
		RETURN;
	END

	INSERT INTO socios.TarifaActividadDeportiva (
        id_actividad_dep,
        vigente_desde,
        vigente_hasta,
        valor
    )
    VALUES (
        @id_actividad_dep,
        @vigente_desde,
        @vigente_hasta,
        @valor
    );
END
GO

/***********************************************************************
Nombre del procedimiento: socios.cargar_tarifa_rec_sp
Descripci�n: Cargar tarifa recreativa
Autor: Grupo 05 - Com2900
***********************************************************************/

CREATE OR ALTER PROCEDURE socios.cargar_tarifa_rec_sp
	@id_actividad_rec INT,
	@vigente_desde DATE = NULL,
	@vigente_hasta DATE = NULL,
	@valor DECIMAL(10,2),
	@modalidad VARCHAR(10),
	@edad_maxima INT,
	@invitado BIT
AS
BEGIN
    SET NOCOUNT ON;

	-- Validamos el valor
	IF @valor IS NULL OR @valor < 0
	BEGIN
		RAISERROR('El valor de la tarifa debe ser positivo.', 16, 1);
		RETURN;
	END

	-- Validamos la actividad recreativa
	IF NOT EXISTS(SELECT 1 FROM socios.ActividadRecreativa WHERE id_actividad_rec = @id_actividad_rec)
	BEGIN
		RAISERROR('La actividad Recreativa no existe.', 16, 1);
		RETURN;
	END

	-- Validamos modalidad
	IF @modalidad IS NULL
	BEGIN
		RAISERROR('La modalidad no puede ser nula.', 16, 1);
		RETURN;
	END

	-- Validamos invitado
	IF @invitado IS NULL
	BEGIN
		RAISERROR('El par�metro invitado no puede ser nulo.', 16, 1);
		RETURN;
	END

	-- Validamos edad_maxima en caso de no ser null
	IF @edad_maxima IS NOT NULL AND @edad_maxima <= 0
	BEGIN
		RAISERROR('La edad m�xima debe ser positiva.', 16, 1);
		RETURN;
	END

	IF @vigente_desde IS NULL
        SET @vigente_desde = GETDATE();

	-- Validaci�n de fechas
	IF @vigente_desde IS NOT NULL AND @vigente_hasta IS NOT NULL
	BEGIN
		IF @vigente_desde > @vigente_hasta
		BEGIN
		    RAISERROR('La fecha de inicio no puede ser mayor que la fecha de fin.', 16, 1);
			RETURN;
		END
	END

	DECLARE @fecha_null DATE = '9999-12-31';
	-- Validar que no exista una tarifa para esas fechas
    IF EXISTS (
        SELECT 1 
        FROM socios.TarifaActividadRecreativa
        WHERE id_actividad_rec = @id_actividad_rec
			AND modalidad = @modalidad
			AND edad_maxima = @edad_maxima
			AND invitado = @invitado
			AND (
				-- Condici�n de solapamiento:
				-- El inicio del nuevo rango (@vigente_desde) es menor o igual al fin del rango existente (o "sin limite").
				@vigente_desde <= ISNULL(vigente_hasta, @fecha_null)
				AND
				-- El inicio del rango existente (vigente_desde) es menor o igual al fin del nuevo rango (o "sin limite").
				vigente_desde <= ISNULL(@vigente_hasta, @fecha_null)
			)
    )
    BEGIN
        RAISERROR('Ya existe una tarifa vigente para las fechas dadas.', 16, 1);
		RETURN;
	END

	INSERT INTO socios.TarifaActividadRecreativa(
        id_actividad_rec,
        vigente_desde,
        vigente_hasta,
        valor,
		modalidad,
		edad_maxima,
		invitado
    )
    VALUES (
        @id_actividad_rec,
        @vigente_desde,
        @vigente_hasta,
        @valor,
		@modalidad,
		@edad_maxima,
		@invitado
    );
END
GO
